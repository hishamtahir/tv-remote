package com.hend.tvremote;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Swipe to move, tap to select. Long swipes move several steps. */
public class TouchpadView extends View {

    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintSmall = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private DpadView.OnPadListener listener;
    private final float step;
    private final float tapSlop;
    private float downX, downY, lastX, lastY, touchX, touchY;
    private long downTime;
    private boolean moved;
    private boolean touching;
    private int tapAlpha;

    private final Runnable fadeTap = new Runnable() {
        @Override
        public void run() {
            tapAlpha -= 25;
            if (tapAlpha > 0) {
                invalidate();
                postDelayed(this, 16);
            } else {
                tapAlpha = 0;
                invalidate();
            }
        }
    };

    public TouchpadView(Context c) {
        this(c, null);
    }

    public TouchpadView(Context c, AttributeSet attrs) {
        super(c, attrs);
        step = Ui.dp(c, 44);
        tapSlop = Ui.dp(c, 12);
        bg.setColor(c.getColor(R.color.surface));
        border.setColor(c.getColor(R.color.surface2));
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(Ui.dp(c, 1.5f));
        hint.setColor(c.getColor(R.color.muted));
        hint.setTextAlign(Paint.Align.CENTER);
        hint.setTextSize(Ui.dp(c, 16));
        hintSmall.setColor(c.getColor(R.color.surface3));
        hintSmall.setTextAlign(Paint.Align.CENTER);
        hintSmall.setTextSize(Ui.dp(c, 13));
        dot.setColor(c.getColor(R.color.accent));
        setContentDescription("لوحة اللمس");
    }

    public void setOnPadListener(DpadView.OnPadListener l) {
        listener = l;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float r = Ui.dp(getContext(), 28);
        float inset = Ui.dp(getContext(), 2);
        rect.set(inset, inset, getWidth() - inset, getHeight() - inset);
        canvas.drawRoundRect(rect, r, r, bg);
        canvas.drawRoundRect(rect, r, r, border);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        if (!touching && tapAlpha == 0) {
            canvas.drawText("اسحبي للتنقل", cx, cy - Ui.dp(getContext(), 6), hint);
            canvas.drawText("اضغطي للاختيار", cx, cy + Ui.dp(getContext(), 18), hintSmall);
        }
        if (touching) {
            dot.setAlpha(90);
            canvas.drawCircle(touchX, touchY, Ui.dp(getContext(), 30), dot);
            dot.setAlpha(255);
            canvas.drawCircle(touchX, touchY, Ui.dp(getContext(), 8), dot);
        }
        if (tapAlpha > 0) {
            dot.setAlpha(tapAlpha);
            float grow = Ui.dp(getContext(), 30) + (255 - tapAlpha) / 4f;
            canvas.drawCircle(touchX, touchY, grow, dot);
            dot.setAlpha(255);
        }
    }

    private void fire(int key) {
        Ui.tap(this);
        if (listener != null) listener.onPad(key);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX();
        float y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = touchX = x;
                downY = lastY = touchY = y;
                downTime = System.currentTimeMillis();
                moved = false;
                touching = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE: {
                touchX = x;
                touchY = y;
                float dx = x - lastX;
                float dy = y - lastY;
                if (Math.abs(dx) >= step || Math.abs(dy) >= step) {
                    int key;
                    if (Math.abs(dx) > Math.abs(dy)) {
                        key = dx > 0 ? Keys.RIGHT : Keys.LEFT;
                    } else {
                        key = dy > 0 ? Keys.DOWN : Keys.UP;
                    }
                    fire(key);
                    lastX = x;
                    lastY = y;
                    moved = true;
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP: {
                touching = false;
                float dist = (float) Math.hypot(x - downX, y - downY);
                if (!moved && dist < tapSlop && System.currentTimeMillis() - downTime < 450) {
                    fire(Keys.CENTER);
                    tapAlpha = 160;
                    removeCallbacks(fadeTap);
                    post(fadeTap);
                }
                performClick();
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                touching = false;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}
