package com.hend.tvremote;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** Sends remote-control commands to a paired Android TV over port 6466 and reports its state. */
public class RemoteClient {

    public static final int PORT = 6466;

    public interface Listener {
        void onReady();

        void onDisconnected(Exception e);

        void onTvInfo(String vendor, String model);

        void onPower(boolean on);

        void onVolume(int level, int max, boolean muted);

        void onCurrentApp(String packageName);

        void onKeyboardShown();
    }

    // RemoteMessage field numbers
    private static final int F_CONFIGURE = 1;
    private static final int F_SET_ACTIVE = 2;
    private static final int F_ERROR = 3;
    private static final int F_PING_REQUEST = 8;
    private static final int F_PING_RESPONSE = 9;
    private static final int F_KEY_INJECT = 10;
    private static final int F_IME_KEY_INJECT = 20;
    private static final int F_IME_BATCH_EDIT = 21;
    private static final int F_IME_SHOW_REQUEST = 22;
    private static final int F_START = 40;
    private static final int F_SET_VOLUME_LEVEL = 50;
    private static final int F_APP_LINK = 90;

    public static final int DIRECTION_START_LONG = 1;
    public static final int DIRECTION_END_LONG = 2;
    public static final int DIRECTION_SHORT = 3;
    private static final int FEATURES = 622;

    private final SSLSocketFactory factory;
    private final String host;
    private final String model;
    private final String vendor;
    private final Listener listener;
    private final CountDownLatch ready = new CountDownLatch(1);

    private SSLSocket socket;
    private InputStream in;
    private OutputStream out;
    private volatile boolean closed;
    private volatile boolean connected;

    private volatile int imeCounter;
    private volatile int fieldCounter;
    private volatile boolean imeKnown;

    public RemoteClient(SSLSocketFactory factory, String host, String model, String vendor, Listener listener) {
        this.factory = factory;
        this.host = host;
        this.model = model;
        this.vendor = vendor;
        this.listener = listener;
    }

    public void connect() throws Exception {
        socket = (SSLSocket) factory.createSocket();
        socket.connect(new InetSocketAddress(host, PORT), 5000);
        socket.startHandshake();
        in = socket.getInputStream();
        out = socket.getOutputStream();
        connected = true;
        Thread reader = new Thread(this::readLoop, "tv-reader");
        reader.setDaemon(true);
        reader.start();
        if (!ready.await(5, TimeUnit.SECONDS)) {
            // Some TVs are slow to answer; commands usually still work.
            ready.countDown();
            listener.onReady();
        }
    }

    public boolean isConnected() {
        return connected && !closed;
    }

    /** True when the TV has told us about a focused text field. */
    public boolean canTypeText() {
        return imeKnown;
    }

    public void sendKey(int keyCode) throws IOException {
        sendKey(keyCode, DIRECTION_SHORT);
    }

    public void sendKey(int keyCode, int direction) throws IOException {
        send(new Proto.Writer().message(F_KEY_INJECT, new Proto.Writer()
                .varint(1, keyCode)
                .varint(2, direction)));
    }

    /** Replaces the text of the TV's focused text field. */
    public void sendText(String text) throws IOException {
        int pos = Math.max(text.length() - 1, 0);
        Proto.Writer value = new Proto.Writer()
                .varint(1, pos)
                .varint(2, pos)
                .string(3, text);
        Proto.Writer editInfo = new Proto.Writer()
                .varint(1, 1)
                .message(2, value);
        send(new Proto.Writer().message(F_IME_BATCH_EDIT, new Proto.Writer()
                .varint(1, imeCounter)
                .varint(2, fieldCounter)
                .message(3, editInfo)));
    }

    public void launchApp(String link) throws IOException {
        send(new Proto.Writer().message(F_APP_LINK, new Proto.Writer().string(1, link)));
    }

    public void close() {
        closed = true;
        connected = false;
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }

    private void readLoop() {
        try {
            while (!closed) {
                handle(Proto.Message.parse(Proto.readDelimited(in)));
            }
        } catch (Exception e) {
            connected = false;
            if (!closed) {
                closed = true;
                listener.onDisconnected(e);
            }
        }
    }

    void handle(Proto.Message m) throws IOException {
        if (m.has(F_CONFIGURE)) {
            Proto.Message cfg = m.getMessage(F_CONFIGURE);
            Proto.Message info = cfg == null ? null : cfg.getMessage(2);
            if (info != null) {
                listener.onTvInfo(info.getString(2), info.getString(1));
            }
            Proto.Writer mine = new Proto.Writer()
                    .string(1, model)
                    .string(2, vendor)
                    .varint(3, 1)
                    .string(4, "1")
                    .string(5, "atvremote")
                    .string(6, "1.0.0");
            send(new Proto.Writer().message(F_CONFIGURE, new Proto.Writer()
                    .varint(1, FEATURES)
                    .message(2, mine)));
        } else if (m.has(F_SET_ACTIVE)) {
            send(new Proto.Writer().message(F_SET_ACTIVE,
                    new Proto.Writer().varint(1, FEATURES)));
            if (ready.getCount() > 0) {
                ready.countDown();
                listener.onReady();
            }
        } else if (m.has(F_PING_REQUEST)) {
            Proto.Message ping = m.getMessage(F_PING_REQUEST);
            long val = ping == null ? 0 : ping.getLong(1, 0);
            send(new Proto.Writer().message(F_PING_RESPONSE,
                    new Proto.Writer().varint(1, val)));
        } else if (m.has(F_START)) {
            Proto.Message s = m.getMessage(F_START);
            listener.onPower(s != null && s.getLong(1, 0) != 0);
        } else if (m.has(F_SET_VOLUME_LEVEL)) {
            Proto.Message v = m.getMessage(F_SET_VOLUME_LEVEL);
            if (v != null) {
                listener.onVolume((int) v.getLong(7, 0), (int) v.getLong(6, 100), v.getLong(8, 0) != 0);
            }
        } else if (m.has(F_IME_KEY_INJECT)) {
            Proto.Message k = m.getMessage(F_IME_KEY_INJECT);
            Proto.Message app = k == null ? null : k.getMessage(1);
            String pkg = app == null ? null : app.getString(12);
            if (pkg != null && !pkg.isEmpty()) listener.onCurrentApp(pkg);
        } else if (m.has(F_IME_BATCH_EDIT)) {
            Proto.Message b = m.getMessage(F_IME_BATCH_EDIT);
            if (b != null) {
                imeCounter = (int) b.getLong(1, 0);
                fieldCounter = (int) b.getLong(2, 0);
                imeKnown = true;
            }
        } else if (m.has(F_IME_SHOW_REQUEST)) {
            imeKnown = true;
            listener.onKeyboardShown();
        } else if (m.has(F_ERROR)) {
            throw new IOException("الشاشة أرسلت خطأ");
        }
    }

    private void send(Proto.Writer msg) throws IOException {
        if (out == null) throw new IOException("غير متصل");
        synchronized (this) {
            Proto.writeDelimited(out, msg.toByteArray());
        }
    }
}
