package com.hend.tvremote;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** Sends remote-control commands to a paired Android TV over port 6466. */
public class RemoteClient {

    public static final int PORT = 6466;

    public interface Listener {
        void onReady();
        void onDisconnected(Exception e);
    }

    // RemoteMessage field numbers
    private static final int F_CONFIGURE = 1;
    private static final int F_SET_ACTIVE = 2;
    private static final int F_ERROR = 3;
    private static final int F_PING_REQUEST = 8;
    private static final int F_PING_RESPONSE = 9;
    private static final int F_KEY_INJECT = 10;
    private static final int F_APP_LINK = 90;

    private static final int DIRECTION_SHORT = 3;
    private static final int FEATURES = 622;

    private final SSLSocketFactory factory;
    private final String host;
    private final String model;
    private final String vendor;
    private final Listener listener;
    private final CountDownLatch ready = new CountDownLatch(1);

    private SSLSocket socket;
    private InputStream in;
    private OutputStream out;
    private volatile boolean closed;
    private volatile boolean connected;

    public RemoteClient(SSLSocketFactory factory, String host, String model, String vendor, Listener listener) {
        this.factory = factory;
        this.host = host;
        this.model = model;
        this.vendor = vendor;
        this.listener = listener;
    }

    public void connect() throws Exception {
        socket = (SSLSocket) factory.createSocket();
        socket.connect(new InetSocketAddress(host, PORT), 6000);
        socket.startHandshake();
        in = socket.getInputStream();
        out = socket.getOutputStream();
        connected = true;
        Thread reader = new Thread(this::readLoop, "tv-reader");
        reader.setDaemon(true);
        reader.start();
        if (!ready.await(6, TimeUnit.SECONDS)) {
            // Some TVs are slow to answer; commands usually still work.
            listener.onReady();
        }
    }

    public boolean isConnected() {
        return connected && !closed;
    }

    public void sendKey(int keyCode) throws IOException {
        send(new Proto.Writer().message(F_KEY_INJECT, new Proto.Writer()
                .varint(1, keyCode)
                .varint(2, DIRECTION_SHORT)));
    }

    public void launchApp(String link) throws IOException {
        send(new Proto.Writer().message(F_APP_LINK, new Proto.Writer().string(1, link)));
    }

    public void close() {
        closed = true;
        connected = false;
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }

    private void readLoop() {
        try {
            while (!closed) {
                Proto.Message m = Proto.Message.parse(Proto.readDelimited(in));
                if (m.has(F_CONFIGURE)) {
                    Proto.Writer info = new Proto.Writer()
                            .string(1, model)
                            .string(2, vendor)
                            .varint(3, 1)
                            .string(4, "1")
                            .string(5, "atvremote")
                            .string(6, "1.0.0");
                    send(new Proto.Writer().message(F_CONFIGURE, new Proto.Writer()
                            .varint(1, FEATURES)
                            .message(2, info)));
                } else if (m.has(F_SET_ACTIVE)) {
                    send(new Proto.Writer().message(F_SET_ACTIVE,
                            new Proto.Writer().varint(1, FEATURES)));
                    if (ready.getCount() > 0) {
                        ready.countDown();
                        listener.onReady();
                    }
                } else if (m.has(F_PING_REQUEST)) {
                    Proto.Message ping = m.getMessage(F_PING_REQUEST);
                    long val = ping == null ? 0 : ping.getLong(1, 0);
                    send(new Proto.Writer().message(F_PING_RESPONSE,
                            new Proto.Writer().varint(1, val)));
                } else if (m.has(F_ERROR)) {
                    throw new IOException("الشاشة أرسلت خطأ");
                }
            }
        } catch (Exception e) {
            connected = false;
            if (!closed) {
                closed = true;
                listener.onDisconnected(e);
            }
        }
    }

    private void send(Proto.Writer msg) throws IOException {
        if (out == null) throw new IOException("غير متصل");
        synchronized (this) {
            Proto.writeDelimited(out, msg.toByteArray());
        }
    }
}
