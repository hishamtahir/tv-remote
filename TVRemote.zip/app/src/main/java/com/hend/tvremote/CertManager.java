package com.hend.tvremote;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;

import javax.net.ssl.SSLSocketFactory;

/**
 * Keeps this phone's client certificate in the app's private storage.
 * The TV remembers this certificate after pairing.
 */
public final class CertManager {

    private static Context appContext;
    private static PrivateKey key;
    private static X509Certificate cert;
    private static SSLSocketFactory factory;

    private CertManager() {}

    public static void init(Context c) {
        appContext = c.getApplicationContext();
    }

    private static synchronized void load() throws Exception {
        if (cert != null) return;
        SharedPreferences p = appContext.getSharedPreferences("client_cert", Context.MODE_PRIVATE);
        String k = p.getString("key", null);
        String c = p.getString("cert", null);
        if (k != null && c != null) {
            key = KeyFactory.getInstance("RSA").generatePrivate(
                    new PKCS8EncodedKeySpec(Base64.decode(k, Base64.NO_WRAP)));
            cert = CertGen.parseCert(Base64.decode(c, Base64.NO_WRAP));
            return;
        }
        CertGen.Result r = CertGen.generate();
        key = r.keyPair.getPrivate();
        cert = r.cert;
        p.edit()
                .putString("key", Base64.encodeToString(key.getEncoded(), Base64.NO_WRAP))
                .putString("cert", Base64.encodeToString(cert.getEncoded(), Base64.NO_WRAP))
                .commit();
    }

    public static RSAPublicKey clientPublicKey() throws Exception {
        load();
        return (RSAPublicKey) cert.getPublicKey();
    }

    public static synchronized SSLSocketFactory socketFactory() throws Exception {
        load();
        if (factory == null) factory = CertGen.socketFactory(key, cert);
        return factory;
    }
}
