package com.hend.tvremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;

/** The full pairing experience: connect, show the code dialog, verify, save. */
public final class PairingFlow {

    public interface Callback {
        void onPaired();
    }

    private final Activity activity;
    private final ExecutorService exec;
    private final String name;
    private final String ip;
    private final Callback callback;
    private PairingClient client;
    private AlertDialog progress;
    private boolean cancelled;

    private PairingFlow(Activity a, ExecutorService exec, String name, String ip, Callback cb) {
        this.activity = a;
        this.exec = exec;
        this.name = name;
        this.ip = ip;
        this.callback = cb;
    }

    public static void start(Activity a, ExecutorService exec, String name, String ip, Callback cb) {
        new PairingFlow(a, exec, name, ip, cb).begin();
    }

    private boolean alive() {
        return !activity.isFinishing() && !activity.isDestroyed();
    }

    private void begin() {
        cancelled = false;
        View v = LayoutInflater.from(activity).inflate(R.layout.dialog_progress, null);
        ((TextView) v.findViewById(R.id.progress_text)).setText("جارٍ الاتصال بـ " + name + "…");
        progress = new AlertDialog.Builder(activity)
                .setView(v)
                .setCancelable(true)
                .setOnCancelListener(d -> cancel())
                .show();

        exec.execute(() -> {
            try {
                client = new PairingClient(CertManager.socketFactory(), ip,
                        CertManager.clientPublicKey(), Build.MANUFACTURER + " " + Build.MODEL);
                client.start();
                activity.runOnUiThread(() -> {
                    dismiss(progress);
                    if (cancelled) {
                        closeClient();
                    } else if (alive()) {
                        askCode();
                    }
                });
            } catch (Exception e) {
                closeClient();
                activity.runOnUiThread(() -> {
                    dismiss(progress);
                    if (!cancelled && alive()) showError(e);
                });
            }
        });
    }

    private void askCode() {
        View v = LayoutInflater.from(activity).inflate(R.layout.dialog_pair, null);
        TextView subtitle = v.findViewById(R.id.pair_subtitle);
        final EditText code = v.findViewById(R.id.pair_code);
        final TextView error = v.findViewById(R.id.pair_error);
        subtitle.setText("اكتبي الرمز المكوَّن من 6 خانات الظاهر الآن على شاشة «" + name + "»");
        code.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(6)});

        final AlertDialog dialog = new AlertDialog.Builder(activity)
                .setView(v)
                .setCancelable(false)
                .setPositiveButton("اقتران", null)
                .setNegativeButton("إلغاء", (d, w) -> cancel())
                .create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        dialog.setOnShowListener(d -> {
            final Button ok = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            ok.setOnClickListener(b -> verify(dialog, code, error, ok));
            code.requestFocus();
            code.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

                @Override
                public void onTextChanged(CharSequence s, int st, int b, int c) {
                    error.setVisibility(View.GONE);
                }

                @Override
                public void afterTextChanged(Editable s) {
                    if (s.length() == 6 && ok.isEnabled()) verify(dialog, code, error, ok);
                }
            });
        });
        dialog.show();
    }

    private void verify(AlertDialog dialog, EditText code, TextView error, Button ok) {
        final String value = code.getText().toString().trim();
        if (value.length() != 6) {
            showFieldError(error, "الرمز يتكون من 6 خانات");
            return;
        }
        ok.setEnabled(false);
        code.setEnabled(false);
        error.setVisibility(View.VISIBLE);
        error.setTextColor(activity.getColor(R.color.muted));
        error.setText("جارٍ التحقق…");
        exec.execute(() -> {
            try {
                client.finish(value);
                closeClient();
                TvStore.markPaired(activity, ip, name);
                activity.runOnUiThread(() -> {
                    dismiss(dialog);
                    if (alive()) callback.onPaired();
                });
            } catch (IllegalArgumentException e) {
                activity.runOnUiThread(() -> {
                    ok.setEnabled(true);
                    code.setEnabled(true);
                    code.setText("");
                    code.requestFocus();
                    showFieldError(error, e.getMessage());
                });
            } catch (Exception e) {
                closeClient();
                activity.runOnUiThread(() -> {
                    dismiss(dialog);
                    if (alive()) showError(e);
                });
            }
        });
    }

    private void showFieldError(TextView error, String msg) {
        error.setVisibility(View.VISIBLE);
        error.setTextColor(activity.getColor(R.color.power));
        error.setText(msg);
    }

    private void showError(Exception e) {
        new AlertDialog.Builder(activity)
                .setTitle("تعذر الاقتران")
                .setMessage(Ui.friendly(e)
                        + "\n\n• تأكدي أن الشاشة تعمل وليست في وضع الاستعداد."
                        + "\n• الهاتف والشاشة على نفس شبكة الواي فاي."
                        + "\n• الشاشة من نوع Android TV أو Google TV.")
                .setPositiveButton("إعادة المحاولة", (d, w) -> begin())
                .setNegativeButton("إغلاق", null)
                .show();
    }

    private void cancel() {
        cancelled = true;
        exec.execute(this::closeClient);
    }

    private void closeClient() {
        if (client != null) client.close();
    }

    private static void dismiss(AlertDialog d) {
        try {
            if (d != null && d.isShowing()) d.dismiss();
        } catch (Exception ignored) {
        }
    }
}
