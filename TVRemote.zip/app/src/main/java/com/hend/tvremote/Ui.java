package com.hend.tvremote;

import android.content.Context;
import android.view.HapticFeedbackConstants;
import android.view.View;

import java.io.EOFException;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import javax.net.ssl.SSLException;

/** Small UI helpers. */
public final class Ui {

    private Ui() {}

    public static int dp(Context c, float dp) {
        return Math.round(dp * c.getResources().getDisplayMetrics().density);
    }

    @SuppressWarnings("deprecation")
    public static void tap(View v) {
        if (v == null || !TvStore.haptics(v.getContext())) return;
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
    }

    /** Turns technical errors into a clear Arabic message. */
    public static String friendly(Exception e) {
        Throwable t = e;
        while (t != null) {
            if (t instanceof ConnectException || t instanceof NoRouteToHostException
                    || t instanceof SocketTimeoutException || t instanceof UnknownHostException) {
                return "لا يمكن الوصول إلى الشاشة. تأكدي أنها تعمل وأنها على نفس شبكة الواي فاي.";
            }
            if (t instanceof SSLException) {
                return "رفضت الشاشة الاتصال. قد تحتاجين إلى الاقتران من جديد.";
            }
            if (t instanceof EOFException) {
                return "أغلقت الشاشة الاتصال.";
            }
            if (t instanceof IllegalArgumentException && t.getMessage() != null) {
                return t.getMessage();
            }
            t = t.getCause();
        }
        String m = e.getMessage();
        return m == null ? "حدث خطأ غير متوقع." : m;
    }

    /** Friendly names for common Android TV apps. */
    public static String appName(String pkg) {
        if (pkg == null) return null;
        if (pkg.contains("youtube")) return "YouTube";
        if (pkg.contains("netflix")) return "Netflix";
        if (pkg.contains("amazon")) return "Prime Video";
        if (pkg.contains("disney")) return "Disney+";
        if (pkg.contains("shahid")) return "Shahid";
        if (pkg.contains("spotify")) return "Spotify";
        if (pkg.contains("osn")) return "OSN+";
        if (pkg.contains("launcher") || pkg.contains("tvlauncher") || pkg.contains("leanback")) return "الشاشة الرئيسية";
        if (pkg.contains("settings")) return "الإعدادات";
        if (pkg.contains("livetv") || pkg.contains("tv.tuner") || pkg.contains(".tv.")) return "التلفاز";
        return null;
    }
}
