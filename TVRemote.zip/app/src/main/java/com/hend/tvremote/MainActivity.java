package com.hend.tvremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String SERVICE_TYPE = "_androidtvremote2._tcp.";

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final List<String> names = new ArrayList<>();
    private final List<String> ips = new ArrayList<>();
    private final Deque<NsdServiceInfo> resolveQueue = new ArrayDeque<>();
    private boolean resolving;

    private ArrayAdapter<String> adapter;
    private TextView status;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discoveryListener;
    private WifiManager.MulticastLock multicastLock;
    private PairingClient pairing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        ListView list = findViewById(R.id.tv_list);
        EditText ipInput = findViewById(R.id.ip_input);
        Button connectBtn = findViewById(R.id.connect_btn);

        adapter = new ArrayAdapter<>(this, R.layout.item_tv, names);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) ->
                select(names.get(position), ips.get(position)));

        connectBtn.setOnClickListener(v -> {
            String ip = ipInput.getText().toString().trim();
            if (ip.isEmpty()) {
                Toast.makeText(this, "اكتبي عنوان IP الخاص بالشاشة", Toast.LENGTH_SHORT).show();
                return;
            }
            select(ip, ip);
        });

        SharedPreferences p = prefs(this);
        String lastIp = p.getString("last_ip", null);
        if (lastIp != null) {
            addTv("⭐ " + p.getString("last_name", lastIp), lastIp);
        }

        nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startDiscovery();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopDiscovery();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pairing != null) pairing.close();
        exec.shutdownNow();
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("tv", MODE_PRIVATE);
    }

    static boolean isPaired(Context c, String ip) {
        return prefs(c).getBoolean("paired_" + ip, false);
    }

    static void setPaired(Context c, String ip, boolean paired) {
        prefs(c).edit().putBoolean("paired_" + ip, paired).apply();
    }

    // ---------- Discovery ----------

    private void startDiscovery() {
        WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifi != null) {
            multicastLock = wifi.createMulticastLock("tvremote");
            multicastLock.setReferenceCounted(false);
            multicastLock.acquire();
        }
        status.setText("جارٍ البحث عن الشاشات على نفس الواي فاي…");

        discoveryListener = new NsdManager.DiscoveryListener() {
            @Override
            public void onDiscoveryStarted(String serviceType) {}

            @Override
            public void onServiceFound(NsdServiceInfo info) {
                runOnUiThread(() -> queueResolve(info));
            }

            @Override
            public void onServiceLost(NsdServiceInfo info) {}

            @Override
            public void onDiscoveryStopped(String serviceType) {}

            @Override
            public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                runOnUiThread(() -> status.setText("تعذر البحث التلقائي. اكتبي عنوان IP الشاشة بالأسفل."));
            }

            @Override
            public void onStopDiscoveryFailed(String serviceType, int errorCode) {}
        };
        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener);
        } catch (Exception e) {
            status.setText("تعذر البحث التلقائي. اكتبي عنوان IP الشاشة بالأسفل.");
        }
    }

    private void stopDiscovery() {
        try {
            if (discoveryListener != null) nsd.stopServiceDiscovery(discoveryListener);
        } catch (Exception ignored) {
        }
        discoveryListener = null;
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
    }

    private void queueResolve(NsdServiceInfo info) {
        resolveQueue.add(info);
        resolveNext();
    }

    @SuppressWarnings("deprecation")
    private void resolveNext() {
        if (resolving || resolveQueue.isEmpty()) return;
        resolving = true;
        NsdServiceInfo info = resolveQueue.poll();
        nsd.resolveService(info, new NsdManager.ResolveListener() {
            @Override
            public void onResolveFailed(NsdServiceInfo serviceInfo, int errorCode) {
                runOnUiThread(() -> {
                    resolving = false;
                    resolveNext();
                });
            }

            @Override
            public void onServiceResolved(NsdServiceInfo s) {
                String ip = s.getHost() == null ? null : s.getHost().getHostAddress();
                String name = s.getServiceName();
                runOnUiThread(() -> {
                    resolving = false;
                    if (ip != null) {
                        addTv(name, ip);
                        status.setText("اضغطي على شاشتك من القائمة");
                    }
                    resolveNext();
                });
            }
        });
    }

    private void addTv(String name, String ip) {
        if (ips.contains(ip)) return;
        names.add(name);
        ips.add(ip);
        adapter.notifyDataSetChanged();
    }

    // ---------- Pairing ----------

    private void select(String name, String ip) {
        String clean = name.replace("⭐ ", "");
        if (isPaired(this, ip)) {
            openRemote(clean, ip);
        } else {
            startPairing(clean, ip);
        }
    }

    private void startPairing(String name, String ip) {
        status.setText("جارٍ الاتصال بالشاشة " + name + "…");
        exec.execute(() -> {
            try {
                if (pairing != null) pairing.close();
                pairing = new PairingClient(CertManager.socketFactory(), ip,
                        CertManager.clientPublicKey(), Build.MODEL);
                pairing.start();
                runOnUiThread(() -> askCode(name, ip));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("تعذر الاتصال بالشاشة: " + message(e)
                        + "\nتأكدي أن الهاتف والشاشة على نفس الواي فاي وأن الشاشة تعمل."));
            }
        });
    }

    private void askCode(String name, String ip) {
        status.setText("ظهر رمز على الشاشة. اكتبيه هنا.");
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(6)});
        input.setGravity(Gravity.CENTER);
        input.setTextSize(28);
        input.setHint("مثال: 1A2B3C");

        new AlertDialog.Builder(this)
                .setTitle("رمز الاقتران")
                .setMessage("اكتبي الرمز المكون من 6 خانات الظاهر على شاشة " + name)
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("تأكيد", (d, w) -> finishPairing(name, ip, input.getText().toString()))
                .setNegativeButton("إلغاء", (d, w) -> {
                    exec.execute(() -> {
                        if (pairing != null) pairing.close();
                    });
                    status.setText("تم الإلغاء");
                })
                .show();
    }

    private void finishPairing(String name, String ip, String code) {
        status.setText("جارٍ التحقق من الرمز…");
        exec.execute(() -> {
            try {
                pairing.finish(code);
                pairing.close();
                setPaired(this, ip, true);
                runOnUiThread(() -> {
                    Toast.makeText(this, "تم الاقتران بنجاح ✅", Toast.LENGTH_SHORT).show();
                    openRemote(name, ip);
                });
            } catch (IllegalArgumentException e) {
                // Wrong code: the connection is still open, ask again.
                runOnUiThread(() -> {
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                    askCode(name, ip);
                });
            } catch (Exception e) {
                pairing.close();
                runOnUiThread(() -> status.setText("فشل الاقتران: " + message(e) + "\nحاولي مرة أخرى."));
            }
        });
    }

    private void openRemote(String name, String ip) {
        prefs(this).edit().putString("last_ip", ip).putString("last_name", name).apply();
        Intent i = new Intent(this, RemoteActivity.class);
        i.putExtra("ip", ip);
        i.putExtra("name", name);
        startActivity(i);
    }

    static String message(Exception e) {
        String m = e.getMessage();
        return m == null ? e.getClass().getSimpleName() : m;
    }
}
