package com.hend.tvremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Devices screen: saved TVs, TVs found on the Wi-Fi, manual add, settings. */
public class MainActivity extends Activity {

    private static final String SERVICE_TYPE = "_androidtvremote2._tcp.";

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, String> found = new LinkedHashMap<>();
    private final Deque<NsdServiceInfo> resolveQueue = new ArrayDeque<>();
    private boolean resolving;

    private LinearLayout savedList;
    private LinearLayout foundList;
    private TextView savedTitle;
    private TextView foundEmpty;
    private ProgressBar scanning;

    private NsdManager nsd;
    private NsdManager.DiscoveryListener discoveryListener;
    private WifiManager.MulticastLock multicastLock;

    private final Runnable scanTimeout = () -> {
        scanning.setVisibility(View.INVISIBLE);
        if (found.isEmpty()) {
            foundEmpty.setText("لم نجد شاشات جديدة.\n\n"
                    + "• تأكدي أن الشاشة تعمل وأنها على نفس الواي فاي.\n"
                    + "• يعمل التطبيق مع شاشات Android TV و Google TV (مثل Sony و TCL و Xiaomi و Philips).\n"
                    + "• يمكنك إضافة الشاشة بعنوان IP من الزر بالأسفل.");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CertManager.init(this);

        savedList = findViewById(R.id.saved_list);
        foundList = findViewById(R.id.found_list);
        savedTitle = findViewById(R.id.saved_title);
        foundEmpty = findViewById(R.id.found_empty);
        scanning = findViewById(R.id.scanning);
        nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);

        findViewById(R.id.btn_refresh).setOnClickListener(v -> {
            Ui.tap(v);
            found.clear();
            render();
            stopDiscovery();
            startDiscovery();
        });
        findViewById(R.id.btn_settings).setOnClickListener(v -> showSettings());
        findViewById(R.id.btn_add_ip).setOnClickListener(v -> showAddIp());

        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            ((TextView) findViewById(R.id.version)).setText("الإصدار " + pi.versionName);
        } catch (Exception ignored) {
        }

        // Go straight to the last remote when the app is opened normally.
        if (savedInstanceState == null && TvStore.autoOpen(this)) {
            TvStore.Tv last = TvStore.lastPaired(this);
            if (last != null) openRemote(last.ip, last.name);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
        startDiscovery();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopDiscovery();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        exec.shutdownNow();
    }

    // ---------- List ----------

    private void render() {
        List<TvStore.Tv> saved = TvStore.list(this);
        savedList.removeAllViews();
        savedTitle.setVisibility(saved.isEmpty() ? View.GONE : View.VISIBLE);
        for (TvStore.Tv tv : saved) {
            String detail = (tv.model == null || tv.model.isEmpty() ? "" : tv.model + " • ") + tv.ip;
            View card = card(tv.name, detail, tv.paired ? "مقترنة" : "اقتران", tv.paired);
            card.setOnClickListener(v -> {
                Ui.tap(v);
                if (tv.paired) openRemote(tv.ip, tv.name);
                else pair(tv.name, tv.ip);
            });
            card.setOnLongClickListener(v -> {
                Ui.tap(v);
                showTvOptions(tv);
                return true;
            });
            savedList.addView(card);
        }

        foundList.removeAllViews();
        int shown = 0;
        for (Map.Entry<String, String> e : found.entrySet()) {
            if (TvStore.get(this, e.getKey()) != null) continue;
            final String ip = e.getKey();
            final String name = e.getValue();
            View card = card(name, ip, "اقتران", false);
            card.setOnClickListener(v -> {
                Ui.tap(v);
                pair(name, ip);
            });
            foundList.addView(card);
            shown++;
        }
        if (shown > 0) {
            foundEmpty.setVisibility(View.GONE);
        } else {
            foundEmpty.setVisibility(View.VISIBLE);
            if (!found.isEmpty()) foundEmpty.setText("كل الشاشات الموجودة على الشبكة محفوظة في «شاشاتي».");
        }
    }

    private View card(String name, String detail, String badge, boolean ok) {
        View v = LayoutInflater.from(this).inflate(R.layout.item_device, savedList, false);
        ((TextView) v.findViewById(R.id.dev_name)).setText(name);
        ((TextView) v.findViewById(R.id.dev_detail)).setText(detail);
        TextView b = v.findViewById(R.id.dev_badge);
        b.setText(badge);
        b.setBackgroundResource(ok ? R.drawable.bg_badge_ok : R.drawable.bg_badge_accent);
        b.setTextColor(getColor(ok ? R.color.ok : R.color.accent));
        return v;
    }

    private void showTvOptions(TvStore.Tv tv) {
        String[] items = {"إعادة التسمية", "الاقتران من جديد", "حذف الشاشة"};
        new AlertDialog.Builder(this)
                .setTitle(tv.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) rename(tv);
                    else if (which == 1) pair(tv.name, tv.ip);
                    else confirmDelete(tv);
                })
                .show();
    }

    private void rename(TvStore.Tv tv) {
        EditText input = dialogInput(tv.name, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        new AlertDialog.Builder(this)
                .setTitle("اسم الشاشة")
                .setView(wrap(input))
                .setPositiveButton("حفظ", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (!name.isEmpty()) {
                        TvStore.rename(this, tv.ip, name);
                        render();
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void confirmDelete(TvStore.Tv tv) {
        new AlertDialog.Builder(this)
                .setTitle("حذف «" + tv.name + "»؟")
                .setMessage("ستحتاجين إلى الاقتران من جديد لاستخدامها.")
                .setPositiveButton("حذف", (d, w) -> {
                    TvStore.remove(this, tv.ip);
                    render();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void showAddIp() {
        EditText input = dialogInput("", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("مثال: 192.168.1.20");
        input.setTextDirection(View.TEXT_DIRECTION_LTR);
        new AlertDialog.Builder(this)
                .setTitle("إضافة شاشة")
                .setMessage("تجدين عنوان IP في الشاشة من: الإعدادات ← الشبكة والإنترنت ← اسم شبكة الواي فاي.")
                .setView(wrap(input))
                .setPositiveButton("اقتران", (d, w) -> {
                    String ip = input.getText().toString().trim();
                    if (!ip.matches("^(\\d{1,3})(\\.\\d{1,3}){3}$")) {
                        Toast.makeText(this, "عنوان IP غير صحيح", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    TvStore.Tv existing = TvStore.get(this, ip);
                    if (existing != null && existing.paired) openRemote(ip, existing.name);
                    else pair(found.containsKey(ip) ? found.get(ip) : "الشاشة", ip);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void showSettings() {
        String[] items = {
                "اهتزاز خفيف عند الضغط",
                "أزرار الصوت في الهاتف تتحكم بصوت الشاشة",
                "فتح آخر شاشة تلقائياً عند تشغيل التطبيق"};
        final String[] keys = {"haptics", "volume_keys", "auto_open"};
        boolean[] checked = {TvStore.haptics(this), TvStore.volumeKeys(this), TvStore.autoOpen(this)};
        new AlertDialog.Builder(this)
                .setTitle("الإعدادات")
                .setMultiChoiceItems(items, checked, (d, which, isChecked) ->
                        TvStore.setSetting(this, keys[which], isChecked))
                .setPositiveButton("تم", null)
                .show();
    }

    private EditText dialogInput(String text, int type) {
        EditText input = new EditText(this);
        input.setInputType(type);
        input.setText(text);
        input.setSelection(text.length());
        input.setSingleLine(true);
        input.setTextColor(getColor(R.color.text));
        input.setHintTextColor(getColor(R.color.muted));
        input.setBackgroundResource(R.drawable.bg_input);
        int p = Ui.dp(this, 14);
        input.setPadding(p, p, p, p);
        return input;
    }

    private View wrap(View v) {
        FrameLayout f = new FrameLayout(this);
        int p = Ui.dp(this, 22);
        f.setPadding(p, Ui.dp(this, 8), p, 0);
        f.addView(v);
        return f;
    }

    // ---------- Actions ----------

    private void pair(String name, String ip) {
        PairingFlow.start(this, exec, name, ip, () -> {
            Toast.makeText(this, "تم الاقتران بنجاح ✓", Toast.LENGTH_SHORT).show();
            openRemote(ip, name);
        });
    }

    private void openRemote(String ip, String name) {
        TvStore.touch(this, ip);
        Intent i = new Intent(this, RemoteActivity.class);
        i.putExtra("ip", ip);
        i.putExtra("name", name);
        startActivity(i);
    }

    // ---------- Discovery ----------

    private void startDiscovery() {
        if (discoveryListener != null) return;
        WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifi != null) {
            multicastLock = wifi.createMulticastLock("tvremote");
            multicastLock.setReferenceCounted(false);
            multicastLock.acquire();
        }
        scanning.setVisibility(View.VISIBLE);
        if (found.isEmpty()) foundEmpty.setText("نبحث عن الشاشات…");
        handler.removeCallbacks(scanTimeout);
        handler.postDelayed(scanTimeout, 8000);

        discoveryListener = new NsdManager.DiscoveryListener() {
            @Override
            public void onDiscoveryStarted(String serviceType) {}

            @Override
            public void onServiceFound(NsdServiceInfo info) {
                runOnUiThread(() -> queueResolve(info));
            }

            @Override
            public void onServiceLost(NsdServiceInfo info) {}

            @Override
            public void onDiscoveryStopped(String serviceType) {}

            @Override
            public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                runOnUiThread(() -> {
                    discoveryListener = null;
                    scanning.setVisibility(View.INVISIBLE);
                    foundEmpty.setText("تعذر البحث التلقائي. أضيفي الشاشة بعنوان IP.");
                });
            }

            @Override
            public void onStopDiscoveryFailed(String serviceType, int errorCode) {}
        };
        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener);
        } catch (Exception e) {
            discoveryListener = null;
            scanning.setVisibility(View.INVISIBLE);
        }
    }

    private void stopDiscovery() {
        handler.removeCallbacks(scanTimeout);
        try {
            if (discoveryListener != null) nsd.stopServiceDiscovery(discoveryListener);
        } catch (Exception ignored) {
        }
        discoveryListener = null;
        resolveQueue.clear();
        resolving = false;
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
    }

    private void queueResolve(NsdServiceInfo info) {
        resolveQueue.add(info);
        resolveNext();
    }

    @SuppressWarnings("deprecation")
    private void resolveNext() {
        if (resolving || resolveQueue.isEmpty()) return;
        resolving = true;
        NsdServiceInfo info = resolveQueue.poll();
        try {
            nsd.resolveService(info, new NsdManager.ResolveListener() {
                @Override
                public void onResolveFailed(NsdServiceInfo serviceInfo, int errorCode) {
                    runOnUiThread(() -> {
                        resolving = false;
                        resolveNext();
                    });
                }

                @Override
                public void onServiceResolved(NsdServiceInfo s) {
                    String ip = s.getHost() == null ? null : s.getHost().getHostAddress();
                    String name = s.getServiceName();
                    runOnUiThread(() -> {
                        resolving = false;
                        if (ip != null && !ip.contains(":")) {
                            found.put(ip, name);
                            render();
                        }
                        resolveNext();
                    });
                }
            });
        } catch (Exception e) {
            resolving = false;
        }
    }
}
