package com.hend.tvremote;

import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

/** Fires once on press, then repeats while the finger stays down (volume, channels…). */
public class RepeatTouch implements View.OnTouchListener {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable action;
    private final Runnable repeat = new Runnable() {
        @Override
        public void run() {
            action.run();
            handler.postDelayed(this, 130);
        }
    };

    public RepeatTouch(Runnable action) {
        this.action = action;
    }

    @Override
    public boolean onTouch(View v, MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                v.setPressed(true);
                v.drawableHotspotChanged(e.getX(), e.getY());
                Ui.tap(v);
                action.run();
                handler.postDelayed(repeat, 450);
                return true;
            case MotionEvent.ACTION_UP:
                v.performClick();
                // fall through
            case MotionEvent.ACTION_CANCEL:
                v.setPressed(false);
                handler.removeCallbacks(repeat);
                return true;
            default:
                return true;
        }
    }
}
