package com.hend.tvremote;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.security.MessageDigest;
import java.security.cert.Certificate;
import java.security.interfaces.RSAPublicKey;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Pairing with an Android TV / Google TV over port 6467 (Polo protocol).
 * start() makes the TV show a 6-character code; finish(code) completes pairing.
 */
public class PairingClient {

    public static final int PORT = 6467;
    private static final int STATUS_OK = 200;

    // Outer message field numbers
    private static final int F_PAIRING_REQUEST = 10;
    private static final int F_PAIRING_REQUEST_ACK = 11;
    private static final int F_OPTIONS = 20;
    private static final int F_CONFIGURATION = 30;
    private static final int F_CONFIGURATION_ACK = 31;
    private static final int F_SECRET = 40;
    private static final int F_SECRET_ACK = 41;

    private static final int ENCODING_HEXADECIMAL = 3;
    private static final int ROLE_INPUT = 1;

    private final SSLSocketFactory factory;
    private final String host;
    private final RSAPublicKey clientKey;
    private final String clientName;

    private SSLSocket socket;
    private InputStream in;
    private OutputStream out;
    private RSAPublicKey serverKey;

    public PairingClient(SSLSocketFactory factory, String host, RSAPublicKey clientKey, String clientName) {
        this.factory = factory;
        this.host = host;
        this.clientKey = clientKey;
        this.clientName = clientName;
    }

    /** Connects and asks the TV to display the pairing code. */
    public void start() throws Exception {
        socket = (SSLSocket) factory.createSocket();
        socket.connect(new InetSocketAddress(host, PORT), 6000);
        socket.setSoTimeout(15000);
        socket.startHandshake();
        Certificate[] certs = socket.getSession().getPeerCertificates();
        serverKey = (RSAPublicKey) certs[0].getPublicKey();
        in = socket.getInputStream();
        out = socket.getOutputStream();

        send(F_PAIRING_REQUEST, new Proto.Writer()
                .string(1, "atvremote")
                .string(2, clientName));
        expect(F_PAIRING_REQUEST_ACK);

        Proto.Writer encoding = new Proto.Writer().varint(1, ENCODING_HEXADECIMAL).varint(2, 6);
        send(F_OPTIONS, new Proto.Writer()
                .message(1, encoding)
                .varint(3, ROLE_INPUT));
        expect(F_OPTIONS);

        send(F_CONFIGURATION, new Proto.Writer()
                .message(1, encoding)
                .varint(2, ROLE_INPUT));
        expect(F_CONFIGURATION_ACK);
        // The TV now shows the code. Wait for the user without timing out.
        socket.setSoTimeout(0);
    }

    /** Sends the secret derived from the code shown on the TV. */
    public void finish(String code) throws Exception {
        code = code.trim().toUpperCase();
        if (!code.matches("[0-9A-F]{6}")) {
            throw new IllegalArgumentException("الرمز يجب أن يكون 6 خانات (أرقام وحروف A-F)");
        }
        byte[] secret = computeSecret(clientKey, serverKey, code);
        int check = Integer.parseInt(code.substring(0, 2), 16);
        if ((secret[0] & 0xFF) != check) {
            throw new IllegalArgumentException("الرمز غير صحيح، تأكدي منه وحاولي مرة أخرى");
        }
        socket.setSoTimeout(15000);
        send(F_SECRET, new Proto.Writer().bytes(1, secret));
        expect(F_SECRET_ACK);
    }

    public void close() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }

    static byte[] computeSecret(RSAPublicKey client, RSAPublicKey server, String code) throws Exception {
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        sha.update(unsignedHexBytes(client.getModulus()));
        sha.update(unsignedHexBytes(client.getPublicExponent()));
        sha.update(unsignedHexBytes(server.getModulus()));
        sha.update(unsignedHexBytes(server.getPublicExponent()));
        sha.update(hexToBytes(code.substring(2)));
        return sha.digest();
    }

    /** Big-endian bytes of the number with no sign byte (like Python bytes.fromhex of its hex). */
    static byte[] unsignedHexBytes(BigInteger v) {
        String hex = v.toString(16);
        if (hex.length() % 2 == 1) hex = "0" + hex;
        return hexToBytes(hex);
    }

    static byte[] hexToBytes(String hex) {
        byte[] b = new byte[hex.length() / 2];
        for (int i = 0; i < b.length; i++) {
            b[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
        }
        return b;
    }

    private void send(int field, Proto.Writer payload) throws IOException {
        byte[] msg = new Proto.Writer()
                .varint(1, 2)          // protocol_version
                .varint(2, STATUS_OK)  // status
                .message(field, payload)
                .toByteArray();
        Proto.writeDelimited(out, msg);
    }

    private Proto.Message expect(int field) throws IOException {
        Proto.Message m = Proto.Message.parse(Proto.readDelimited(in));
        long status = m.getLong(2, 0);
        if (status != STATUS_OK) {
            throw new IOException("الشاشة رفضت الاقتران (status " + status + ")");
        }
        if (!m.has(field)) {
            throw new IOException("رد غير متوقع من الشاشة");
        }
        return m;
    }
}
