package com.hend.tvremote;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Saved TVs and app settings. */
public final class TvStore {

    public static final class Tv {
        public String ip;
        public String name;
        public String model;
        public boolean paired;
        public long lastUsed;
    }

    private TvStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("tvs", Context.MODE_PRIVATE);
    }

    public static synchronized List<Tv> list(Context c) {
        List<Tv> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Tv t = new Tv();
                t.ip = o.getString("ip");
                t.name = o.optString("name", t.ip);
                t.model = o.optString("model", "");
                t.paired = o.optBoolean("paired", false);
                t.lastUsed = o.optLong("lastUsed", 0);
                out.add(t);
            }
        } catch (Exception ignored) {
        }
        Collections.sort(out, (a, b) -> Long.compare(b.lastUsed, a.lastUsed));
        return out;
    }

    public static synchronized Tv get(Context c, String ip) {
        for (Tv t : list(c)) if (t.ip.equals(ip)) return t;
        return null;
    }

    private static void saveAll(Context c, List<Tv> tvs) {
        JSONArray arr = new JSONArray();
        try {
            for (Tv t : tvs) {
                JSONObject o = new JSONObject();
                o.put("ip", t.ip);
                o.put("name", t.name);
                o.put("model", t.model == null ? "" : t.model);
                o.put("paired", t.paired);
                o.put("lastUsed", t.lastUsed);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        prefs(c).edit().putString("list", arr.toString()).apply();
    }

    public static synchronized void put(Context c, Tv tv) {
        List<Tv> tvs = list(c);
        for (int i = 0; i < tvs.size(); i++) {
            if (tvs.get(i).ip.equals(tv.ip)) {
                tvs.set(i, tv);
                saveAll(c, tvs);
                return;
            }
        }
        tvs.add(tv);
        saveAll(c, tvs);
    }

    public static synchronized void markPaired(Context c, String ip, String name) {
        Tv t = get(c, ip);
        if (t == null) {
            t = new Tv();
            t.ip = ip;
            t.name = name;
            t.model = "";
        }
        t.paired = true;
        t.lastUsed = System.currentTimeMillis();
        put(c, t);
    }

    public static synchronized void setPaired(Context c, String ip, boolean paired) {
        Tv t = get(c, ip);
        if (t == null) return;
        t.paired = paired;
        put(c, t);
    }

    public static synchronized void touch(Context c, String ip) {
        Tv t = get(c, ip);
        if (t == null) return;
        t.lastUsed = System.currentTimeMillis();
        put(c, t);
    }

    public static synchronized void setModel(Context c, String ip, String model) {
        Tv t = get(c, ip);
        if (t == null || model == null || model.equals(t.model)) return;
        t.model = model;
        put(c, t);
    }

    public static synchronized void rename(Context c, String ip, String name) {
        Tv t = get(c, ip);
        if (t == null) return;
        t.name = name;
        put(c, t);
    }

    public static synchronized void remove(Context c, String ip) {
        List<Tv> tvs = list(c);
        for (int i = tvs.size() - 1; i >= 0; i--) {
            if (tvs.get(i).ip.equals(ip)) tvs.remove(i);
        }
        saveAll(c, tvs);
    }

    /** The paired TV used most recently, or null. */
    public static Tv lastPaired(Context c) {
        for (Tv t : list(c)) if (t.paired) return t;
        return null;
    }

    // ---------- settings ----------

    private static SharedPreferences settings(Context c) {
        return c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    public static boolean haptics(Context c) {
        return settings(c).getBoolean("haptics", true);
    }

    public static boolean volumeKeys(Context c) {
        return settings(c).getBoolean("volume_keys", true);
    }

    public static boolean autoOpen(Context c) {
        return settings(c).getBoolean("auto_open", true);
    }

    public static boolean touchpadMode(Context c) {
        return settings(c).getBoolean("touchpad", false);
    }

    public static void setSetting(Context c, String key, boolean value) {
        settings(c).edit().putBoolean(key, value).apply();
    }
}
