package com.hend.tvremote;

/** Android key codes understood by the TV. */
public final class Keys {
    private Keys() {}

    public static final int HOME = 3;
    public static final int BACK = 4;
    public static final int NUM_0 = 7;
    public static final int UP = 19;
    public static final int DOWN = 20;
    public static final int LEFT = 21;
    public static final int RIGHT = 22;
    public static final int CENTER = 23;
    public static final int VOLUME_UP = 24;
    public static final int VOLUME_DOWN = 25;
    public static final int POWER = 26;
    public static final int A = 29;
    public static final int COMMA = 55;
    public static final int PERIOD = 56;
    public static final int SPACE = 62;
    public static final int ENTER = 66;
    public static final int DEL = 67;
    public static final int MINUS = 69;
    public static final int SLASH = 76;
    public static final int AT = 77;
    public static final int MENU = 82;
    public static final int PLAY_PAUSE = 85;
    public static final int MEDIA_NEXT = 87;
    public static final int MEDIA_PREVIOUS = 88;
    public static final int REWIND = 89;
    public static final int FAST_FORWARD = 90;
    public static final int MUTE = 164;
    public static final int CHANNEL_UP = 166;
    public static final int CHANNEL_DOWN = 167;
    public static final int GUIDE = 172;
    public static final int SETTINGS = 176;
    public static final int TV_INPUT = 178;

    /** Key code for typing a Latin character, or -1 if there is none. */
    public static int forChar(char ch) {
        char c = Character.toLowerCase(ch);
        if (c >= 'a' && c <= 'z') return A + (c - 'a');
        if (c >= '0' && c <= '9') return NUM_0 + (c - '0');
        switch (c) {
            case ' ': return SPACE;
            case '.': return PERIOD;
            case ',': return COMMA;
            case '-': return MINUS;
            case '/': return SLASH;
            case '@': return AT;
            default: return -1;
        }
    }
}
