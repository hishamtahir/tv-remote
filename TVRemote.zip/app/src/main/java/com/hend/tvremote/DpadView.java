package com.hend.tvremote;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Round direction pad with an OK button in the middle. Arrows repeat while held. */
public class DpadView extends View {

    public interface OnPadListener {
        void onPad(int keyCode);
    }

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPressed = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint divider = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint center = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint centerPressed = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint chevron = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint okText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF oval = new RectF();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private OnPadListener listener;
    private int pressed = -1;
    private float cx, cy, radius, innerRadius;

    private final Runnable repeat = new Runnable() {
        @Override
        public void run() {
            if (pressed > 0 && pressed != Keys.CENTER) {
                fire(pressed);
                handler.postDelayed(this, 120);
            }
        }
    };

    public DpadView(Context c) {
        this(c, null);
    }

    public DpadView(Context c, AttributeSet attrs) {
        super(c, attrs);
        ring.setColor(c.getColor(R.color.surface));
        ringPressed.setColor(c.getColor(R.color.surface3));
        divider.setColor(c.getColor(R.color.bg));
        divider.setStyle(Paint.Style.STROKE);
        divider.setStrokeWidth(Ui.dp(c, 3));
        center.setColor(c.getColor(R.color.accent));
        centerPressed.setColor(c.getColor(R.color.accent_dark));
        chevron.setColor(c.getColor(R.color.text));
        chevron.setStyle(Paint.Style.STROKE);
        chevron.setStrokeWidth(Ui.dp(c, 3));
        chevron.setStrokeCap(Paint.Cap.ROUND);
        chevron.setStrokeJoin(Paint.Join.ROUND);
        okText.setColor(0xFFFFFFFF);
        okText.setTextAlign(Paint.Align.CENTER);
        okText.setFakeBoldText(true);
        okText.setTextSize(Ui.dp(c, 22));
        setContentDescription("أزرار الاتجاهات");
    }

    public void setOnPadListener(OnPadListener l) {
        listener = l;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        cx = w / 2f;
        cy = h / 2f;
        radius = Math.min(w, h) / 2f - Ui.dp(getContext(), 4);
        innerRadius = radius * 0.38f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawCircle(cx, cy, radius, ring);

        if (pressed > 0 && pressed != Keys.CENTER) {
            float start;
            switch (pressed) {
                case Keys.RIGHT: start = -45; break;
                case Keys.DOWN: start = 45; break;
                case Keys.LEFT: start = 135; break;
                default: start = 225; break;
            }
            oval.set(cx - radius, cy - radius, cx + radius, cy + radius);
            canvas.drawArc(oval, start, 90, true, ringPressed);
        }

        // Diagonal separators between the four segments
        float d = 0.7071f;
        for (int i = 0; i < 4; i++) {
            float sx = (i == 0 || i == 3) ? d : -d;
            float sy = (i < 2) ? d : -d;
            canvas.drawLine(cx + sx * innerRadius, cy + sy * innerRadius,
                    cx + sx * radius, cy + sy * radius, divider);
        }

        float mid = (radius + innerRadius) / 2f;
        float s = radius * 0.09f;
        drawChevron(canvas, cx, cy - mid, 0, -1, s);
        drawChevron(canvas, cx, cy + mid, 0, 1, s);
        drawChevron(canvas, cx - mid, cy, -1, 0, s);
        drawChevron(canvas, cx + mid, cy, 1, 0, s);

        canvas.drawCircle(cx, cy, innerRadius + Ui.dp(getContext(), 3), divider);
        canvas.drawCircle(cx, cy, innerRadius, pressed == Keys.CENTER ? centerPressed : center);
        float textY = cy - (okText.descent() + okText.ascent()) / 2f;
        canvas.drawText("OK", cx, textY, okText);
    }

    private void drawChevron(Canvas c, float x, float y, int dx, int dy, float s) {
        path.reset();
        if (dy != 0) {
            path.moveTo(x - s, y - dy * s / 2f);
            path.lineTo(x, y + dy * s / 2f);
            path.lineTo(x + s, y - dy * s / 2f);
        } else {
            path.moveTo(x - dx * s / 2f, y - s);
            path.lineTo(x + dx * s / 2f, y);
            path.lineTo(x - dx * s / 2f, y + s);
        }
        c.drawPath(path, chevron);
    }

    private int hit(float x, float y) {
        float dx = x - cx;
        float dy = y - cy;
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > radius * 1.08) return -1;
        if (dist < innerRadius) return Keys.CENTER;
        double angle = Math.toDegrees(Math.atan2(dy, dx));
        if (angle >= -45 && angle < 45) return Keys.RIGHT;
        if (angle >= 45 && angle < 135) return Keys.DOWN;
        if (angle >= -135 && angle < -45) return Keys.UP;
        return Keys.LEFT;
    }

    private void fire(int key) {
        Ui.tap(this);
        if (listener != null) listener.onPad(key);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int key = hit(e.getX(), e.getY());
                if (key < 0) return false;
                pressed = key;
                fire(key);
                if (key != Keys.CENTER) handler.postDelayed(repeat, 420);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
                performClick();
                // fall through
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(repeat);
                pressed = -1;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacks(repeat);
    }
}
