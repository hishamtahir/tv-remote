package com.hend.tvremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.SSLException;

public class RemoteActivity extends Activity implements RemoteClient.Listener {

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private RemoteClient client;
    private String ip;
    private TextView status;
    private boolean destroyed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remote);
        ip = getIntent().getStringExtra("ip");
        String name = getIntent().getStringExtra("name");

        ((TextView) findViewById(R.id.tv_name)).setText(name);
        status = findViewById(R.id.status);
        hookButtons(findViewById(R.id.root));
        connect();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        destroyed = true;
        exec.execute(() -> {
            if (client != null) client.close();
        });
        exec.shutdown();
    }

    /** Every view with a tag is a button: a number = Android key code, "app:URL" = open an app. */
    private void hookButtons(View v) {
        Object tag = v.getTag();
        if (tag != null) {
            final String t = tag.toString();
            v.setOnClickListener(view -> {
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                if (t.startsWith("app:")) {
                    launch(t.substring(4));
                } else {
                    sendKey(Integer.parseInt(t));
                }
            });
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) hookButtons(g.getChildAt(i));
        }
    }

    private void setStatus(String s) {
        runOnUiThread(() -> status.setText(s));
    }

    private void connect() {
        setStatus("جارٍ الاتصال…");
        exec.execute(this::connectNow);
    }

    /** Runs on the executor thread. */
    private boolean connectNow() {
        try {
            if (client != null) client.close();
            client = new RemoteClient(CertManager.socketFactory(), ip,
                    Build.MODEL, Build.MANUFACTURER, this);
            client.connect();
            return true;
        } catch (SSLException e) {
            needsPairing();
        } catch (Exception e) {
            setStatus("غير متصل: " + MainActivity.message(e) + " — اضغطي أي زر لإعادة المحاولة");
        }
        return false;
    }

    private void sendKey(int code) {
        exec.execute(() -> {
            if (!ensureConnected()) return;
            try {
                client.sendKey(code);
            } catch (Exception e) {
                if (connectNow()) {
                    try {
                        client.sendKey(code);
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    private void launch(String link) {
        exec.execute(() -> {
            if (!ensureConnected()) return;
            try {
                client.launchApp(link);
            } catch (Exception e) {
                setStatus("تعذر فتح التطبيق");
            }
        });
    }

    private boolean ensureConnected() {
        if (client != null && client.isConnected()) return true;
        return connectNow();
    }

    private void needsPairing() {
        MainActivity.setPaired(this, ip, false);
        runOnUiThread(() -> {
            if (destroyed) return;
            new AlertDialog.Builder(this)
                    .setTitle("يلزم الاقتران من جديد")
                    .setMessage("الشاشة لم تتعرف على هذا الهاتف. ارجعي واختاري الشاشة مرة أخرى لإظهار رمز جديد.")
                    .setPositiveButton("حسناً", (d, w) -> finish())
                    .setCancelable(false)
                    .show();
        });
    }

    @Override
    public void onReady() {
        setStatus("متصل ✅");
    }

    @Override
    public void onDisconnected(Exception e) {
        if (destroyed) return;
        if (e instanceof SSLException) {
            needsPairing();
        } else {
            setStatus("انقطع الاتصال — اضغطي أي زر لإعادة الاتصال");
        }
    }
}
