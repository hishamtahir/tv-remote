package com.hend.tvremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.SSLException;

public class RemoteActivity extends Activity implements RemoteClient.Listener {

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private volatile RemoteClient client;
    private String ip;
    private String name;
    private boolean started;
    private boolean repairShown;

    private TextView nameView;
    private TextView status;
    private View statusDot;
    private TextView chipPower;
    private TextView chipApp;
    private TextView chipVolume;
    private TextView kbBanner;
    private TextView segDpad;
    private TextView segTouch;
    private DpadView dpad;
    private TouchpadView touchpad;
    private AlertDialog keyboardDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remote);
        CertManager.init(this);

        ip = getIntent().getStringExtra("ip");
        name = getIntent().getStringExtra("name");

        nameView = findViewById(R.id.tv_name);
        status = findViewById(R.id.status);
        statusDot = findViewById(R.id.status_dot);
        chipPower = findViewById(R.id.chip_power);
        chipApp = findViewById(R.id.chip_app);
        chipVolume = findViewById(R.id.chip_volume);
        kbBanner = findViewById(R.id.kb_banner);
        segDpad = findViewById(R.id.seg_dpad);
        segTouch = findViewById(R.id.seg_touch);
        dpad = findViewById(R.id.dpad);
        touchpad = findViewById(R.id.touchpad);

        TvStore.Tv saved = TvStore.get(this, ip);
        if (saved != null) name = saved.name;
        nameView.setText(name);

        hookTags(findViewById(R.id.root));
        dpad.setOnPadListener(this::sendKey);
        touchpad.setOnPadListener(this::sendKey);
        segDpad.setOnClickListener(v -> setTouchMode(false));
        segTouch.setOnClickListener(v -> setTouchMode(true));
        setTouchMode(TvStore.touchpadMode(this));

        findViewById(R.id.btn_devices).setOnClickListener(v -> finish());
        findViewById(R.id.title_box).setOnClickListener(v -> {
            if (client == null || !client.isConnected()) connect();
        });
        findViewById(R.id.btn_keyboard).setOnClickListener(v -> {
            Ui.tap(v);
            showKeyboard();
        });
        findViewById(R.id.btn_numpad).setOnClickListener(v -> {
            Ui.tap(v);
            showNumpad();
        });
        kbBanner.setOnClickListener(v -> {
            kbBanner.setVisibility(View.GONE);
            showKeyboard();
        });
        setState(State.CONNECTING, "جارٍ الاتصال…");
    }

    @Override
    protected void onStart() {
        super.onStart();
        started = true;
        connect();
    }

    @Override
    protected void onStop() {
        super.onStop();
        started = false;
        final RemoteClient c = client;
        client = null;
        exec.execute(() -> {
            if (c != null) c.close();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        exec.shutdown();
    }

    // ---------- Buttons ----------

    /** "k:NN" = key, "r:NN" = key that repeats while held, "app:URL" = open an app. */
    private void hookTags(View v) {
        Object tag = v.getTag();
        if (tag instanceof String) {
            final String t = (String) tag;
            if (t.startsWith("k:")) {
                final int code = Integer.parseInt(t.substring(2));
                v.setOnClickListener(view -> {
                    Ui.tap(view);
                    sendKey(code);
                });
            } else if (t.startsWith("r:")) {
                final int code = Integer.parseInt(t.substring(2));
                v.setOnTouchListener(new RepeatTouch(() -> sendKey(code)));
            } else if (t.startsWith("app:")) {
                final String link = t.substring(4);
                v.setOnClickListener(view -> {
                    Ui.tap(view);
                    launch(link, ((TextView) view).getText().toString());
                });
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) hookTags(g.getChildAt(i));
        }
    }

    private void setTouchMode(boolean touch) {
        TvStore.setSetting(this, "touchpad", touch);
        dpad.setVisibility(touch ? View.GONE : View.VISIBLE);
        touchpad.setVisibility(touch ? View.VISIBLE : View.GONE);
        styleSegment(segDpad, !touch);
        styleSegment(segTouch, touch);
    }

    private void styleSegment(TextView t, boolean on) {
        t.setBackgroundResource(on ? R.drawable.bg_segment_on : 0);
        t.setTextColor(getColor(on ? R.color.text : R.color.muted));
    }

    /** Phone volume buttons control the TV. */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (TvStore.volumeKeys(this)
                && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            sendKey(keyCode == KeyEvent.KEYCODE_VOLUME_UP ? Keys.VOLUME_UP : Keys.VOLUME_DOWN);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (TvStore.volumeKeys(this)
                && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    // ---------- Connection ----------

    private enum State { CONNECTING, CONNECTED, OFFLINE }

    private void setState(State s, String text) {
        runOnUiThread(() -> {
            int color;
            switch (s) {
                case CONNECTED: color = R.color.ok; break;
                case CONNECTING: color = R.color.warn; break;
                default: color = R.color.power; break;
            }
            Drawable d = statusDot.getBackground().mutate();
            d.setTint(getColor(color));
            status.setText(text);
        });
    }

    private void connect() {
        setState(State.CONNECTING, "جارٍ الاتصال…");
        exec.execute(this::connectNow);
    }

    /** Runs on the executor thread. */
    private boolean connectNow() {
        if (!started) return false;
        try {
            RemoteClient old = client;
            if (old != null) old.close();
            RemoteClient c = new RemoteClient(CertManager.socketFactory(), ip,
                    Build.MODEL, Build.MANUFACTURER, this);
            client = c;
            c.connect();
            return true;
        } catch (SSLException e) {
            needsPairing();
        } catch (Exception e) {
            setState(State.OFFLINE, "غير متصل — اضغطي هنا لإعادة المحاولة");
            showToast(Ui.friendly(e));
        }
        return false;
    }

    private boolean ensureConnected() {
        RemoteClient c = client;
        if (c != null && c.isConnected()) return true;
        setState(State.CONNECTING, "جارٍ إعادة الاتصال…");
        return connectNow();
    }

    private void sendKey(int code) {
        exec.execute(() -> {
            if (!ensureConnected()) return;
            try {
                client.sendKey(code);
            } catch (Exception e) {
                if (connectNow()) {
                    try {
                        client.sendKey(code);
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    private void launch(String link, String appName) {
        exec.execute(() -> {
            if (!ensureConnected()) return;
            try {
                client.launchApp(link);
                showToast("جارٍ فتح " + appName + "…");
            } catch (Exception e) {
                showToast("تعذر فتح " + appName);
            }
        });
    }

    private void showToast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    private void needsPairing() {
        TvStore.setPaired(this, ip, false);
        setState(State.OFFLINE, "يلزم الاقتران");
        runOnUiThread(() -> {
            if (isFinishing() || repairShown) return;
            repairShown = true;
            new AlertDialog.Builder(this)
                    .setTitle("يلزم الاقتران من جديد")
                    .setMessage("لم تتعرف الشاشة على هذا الهاتف. سيظهر رمز جديد على الشاشة لتكتبيه هنا.")
                    .setPositiveButton("اقتران الآن", (d, w) -> PairingFlow.start(this, exec, name, ip, () -> {
                        repairShown = false;
                        connect();
                    }))
                    .setNegativeButton("لاحقاً", (d, w) -> repairShown = false)
                    .setCancelable(false)
                    .show();
        });
    }

    // ---------- Listener (called from the network thread) ----------

    @Override
    public void onReady() {
        setState(State.CONNECTED, "متصل");
    }

    @Override
    public void onDisconnected(Exception e) {
        if (!started) return;
        if (e instanceof SSLException) {
            needsPairing();
        } else {
            setState(State.OFFLINE, "انقطع الاتصال — اضغطي أي زر لإعادة الاتصال");
        }
    }

    @Override
    public void onTvInfo(String vendor, String model) {
        String full = ((vendor == null ? "" : vendor) + " " + (model == null ? "" : model)).trim();
        if (!full.isEmpty()) TvStore.setModel(this, ip, full);
    }

    @Override
    public void onPower(boolean on) {
        runOnUiThread(() -> {
            chipPower.setVisibility(View.VISIBLE);
            chipPower.setText(on ? "● الشاشة تعمل" : "○ وضع الاستعداد");
            chipPower.setTextColor(getColor(on ? R.color.ok : R.color.muted));
        });
    }

    @Override
    public void onVolume(int level, int max, boolean muted) {
        runOnUiThread(() -> {
            chipVolume.setVisibility(View.VISIBLE);
            if (muted) {
                chipVolume.setText("الصوت: مكتوم");
            } else if (max > 0 && max != 100) {
                chipVolume.setText("الصوت: " + Math.round(level * 100f / max) + "%");
            } else {
                chipVolume.setText("الصوت: " + level);
            }
        });
    }

    @Override
    public void onCurrentApp(String packageName) {
        String label = Ui.appName(packageName);
        if (label == null) return;
        runOnUiThread(() -> {
            chipApp.setVisibility(View.VISIBLE);
            chipApp.setText("الآن: " + label);
        });
    }

    @Override
    public void onKeyboardShown() {
        runOnUiThread(() -> {
            if (keyboardDialog == null || !keyboardDialog.isShowing()) {
                kbBanner.setVisibility(View.VISIBLE);
                handler.removeCallbacks(hideBanner);
                handler.postDelayed(hideBanner, 15000);
            }
        });
    }

    private final Runnable hideBanner = () -> kbBanner.setVisibility(View.GONE);

    // ---------- Keyboard ----------

    private void showKeyboard() {
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_keyboard, null);
        final EditText text = v.findViewById(R.id.kb_text);
        final TextView hint = v.findViewById(R.id.kb_hint);
        final RemoteClient c = client;
        final boolean live = c != null && c.canTypeText();

        hint.setText(live
                ? "ما تكتبينه يظهر مباشرة في خانة الكتابة على الشاشة."
                : "اضغطي أولاً على خانة البحث في الشاشة. إن لم يظهر النص، اكتبي بالإنجليزية واضغطي «بحث» وسنرسله حرفاً حرفاً.");

        final Runnable[] pending = new Runnable[1];
        if (live) {
            text.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int st, int c1, int a) {}

                @Override
                public void onTextChanged(CharSequence s, int st, int b, int c1) {}

                @Override
                public void afterTextChanged(Editable s) {
                    final String value = s.toString();
                    if (pending[0] != null) handler.removeCallbacks(pending[0]);
                    pending[0] = () -> sendText(value);
                    handler.postDelayed(pending[0], 250);
                }
            });
        }

        v.findViewById(R.id.kb_delete).setOnClickListener(b -> {
            Ui.tap(b);
            Editable e = text.getText();
            if (e.length() > 0) e.delete(e.length() - 1, e.length());
            if (!live) sendKey(Keys.DEL);
        });
        v.findViewById(R.id.kb_clear).setOnClickListener(b -> {
            Ui.tap(b);
            text.setText("");
        });
        final Runnable submit = () -> {
            String value = text.getText().toString();
            if (!live) typeWithKeys(value);
            if (pending[0] != null) {
                handler.removeCallbacks(pending[0]);
                if (live) sendText(value);
            }
            sendKey(Keys.ENTER);
        };
        v.findViewById(R.id.kb_enter).setOnClickListener(b -> {
            Ui.tap(b);
            submit.run();
            if (keyboardDialog != null) keyboardDialog.dismiss();
        });
        text.setOnEditorActionListener((tv, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                submit.run();
                if (keyboardDialog != null) keyboardDialog.dismiss();
                return true;
            }
            return false;
        });

        keyboardDialog = new AlertDialog.Builder(this)
                .setView(v)
                .setNegativeButton("إغلاق", null)
                .create();
        if (keyboardDialog.getWindow() != null) {
            keyboardDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            keyboardDialog.getWindow().setGravity(Gravity.BOTTOM);
        }
        keyboardDialog.show();
        text.requestFocus();
        kbBanner.setVisibility(View.GONE);
    }

    private void sendText(String value) {
        exec.execute(() -> {
            if (!ensureConnected()) return;
            try {
                client.sendText(value);
            } catch (Exception ignored) {
            }
        });
    }

    private void typeWithKeys(String value) {
        int skipped = 0;
        for (int i = 0; i < value.length(); i++) {
            int k = Keys.forChar(value.charAt(i));
            if (k > 0) sendKey(k);
            else skipped++;
        }
        if (skipped > 0) {
            showToast("بعض الحروف لا يمكن إرسالها بهذه الطريقة. اضغطي على خانة البحث في الشاشة أولاً.");
        }
    }

    // ---------- Number pad ----------

    private void showNumpad() {
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        int pad = Ui.dp(this, 18);
        grid.setPadding(pad, pad, pad, Ui.dp(this, 6));

        TextView title = new TextView(this);
        title.setText("الأرقام");
        title.setTextColor(getColor(R.color.text));
        title.setTextSize(20);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, Ui.dp(this, 12));
        grid.addView(title);

        String[][] rows = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {"رجوع", "0", "OK"}};
        for (String[] row : rows) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            for (String label : row) {
                TextView b = new TextView(this);
                b.setText(label);
                b.setGravity(Gravity.CENTER);
                b.setTextColor(getColor(R.color.text));
                b.setTextSize(label.length() == 1 ? 24 : 15);
                b.setBackgroundResource(R.drawable.bg_chip_btn);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 60), 1);
                int m = Ui.dp(this, 5);
                lp.setMargins(m, m, m, m);
                final int code;
                if (label.equals("OK")) code = Keys.CENTER;
                else if (label.equals("رجوع")) code = Keys.BACK;
                else code = Keys.NUM_0 + Integer.parseInt(label);
                b.setOnClickListener(x -> {
                    Ui.tap(x);
                    sendKey(code);
                });
                r.addView(b, lp);
            }
            grid.addView(r);
        }
        new AlertDialog.Builder(this)
                .setView(grid)
                .setPositiveButton("إغلاق", null)
                .show();
    }
}
