package com.hend.tvremote;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Minimal protobuf encoder/decoder: enough for the Android TV Remote v2 protocol. */
public final class Proto {

    private Proto() {}

    public static final class Writer {
        private final ByteArrayOutputStream out = new ByteArrayOutputStream();

        public Writer varint(int field, long value) {
            tag(field, 0);
            raw(value);
            return this;
        }

        public Writer bytes(int field, byte[] b) {
            tag(field, 2);
            raw(b.length);
            out.write(b, 0, b.length);
            return this;
        }

        public Writer string(int field, String s) {
            return bytes(field, s.getBytes(StandardCharsets.UTF_8));
        }

        public Writer message(int field, Writer w) {
            return bytes(field, w.toByteArray());
        }

        private void tag(int field, int wireType) {
            raw(((long) field << 3) | wireType);
        }

        private void raw(long v) {
            while ((v & ~0x7FL) != 0) {
                out.write((int) ((v & 0x7F) | 0x80));
                v >>>= 7;
            }
            out.write((int) v);
        }

        public byte[] toByteArray() {
            return out.toByteArray();
        }
    }

    public static final class Message {
        private final Map<Integer, List<Object>> fields = new HashMap<>();

        public static Message parse(byte[] data) throws IOException {
            Message m = new Message();
            int[] pos = {0};
            while (pos[0] < data.length) {
                long key = readVarint(data, pos);
                int field = (int) (key >>> 3);
                int wireType = (int) (key & 7);
                Object value;
                switch (wireType) {
                    case 0:
                        value = readVarint(data, pos);
                        break;
                    case 1:
                        pos[0] += 8;
                        value = 0L;
                        break;
                    case 2: {
                        int len = (int) readVarint(data, pos);
                        if (len < 0 || pos[0] + len > data.length) throw new IOException("Bad length");
                        byte[] b = new byte[len];
                        System.arraycopy(data, pos[0], b, 0, len);
                        pos[0] += len;
                        value = b;
                        break;
                    }
                    case 5:
                        pos[0] += 4;
                        value = 0L;
                        break;
                    default:
                        throw new IOException("Unsupported wire type " + wireType);
                }
                List<Object> list = m.fields.get(field);
                if (list == null) {
                    list = new ArrayList<>();
                    m.fields.put(field, list);
                }
                list.add(value);
            }
            return m;
        }

        public boolean has(int field) {
            return fields.containsKey(field);
        }

        public long getLong(int field, long def) {
            List<Object> l = fields.get(field);
            if (l == null || !(l.get(0) instanceof Long)) return def;
            return (Long) l.get(0);
        }

        public byte[] getBytes(int field) {
            List<Object> l = fields.get(field);
            if (l == null || !(l.get(0) instanceof byte[])) return null;
            return (byte[]) l.get(0);
        }

        public String getString(int field) {
            byte[] b = getBytes(field);
            return b == null ? null : new String(b, StandardCharsets.UTF_8);
        }

        public Message getMessage(int field) throws IOException {
            byte[] b = getBytes(field);
            return b == null ? null : parse(b);
        }
    }

    static long readVarint(byte[] data, int[] pos) throws IOException {
        long result = 0;
        int shift = 0;
        while (true) {
            if (pos[0] >= data.length) throw new IOException("Truncated varint");
            int b = data[pos[0]++] & 0xFF;
            result |= (long) (b & 0x7F) << shift;
            if ((b & 0x80) == 0) return result;
            shift += 7;
            if (shift > 63) throw new IOException("Varint too long");
        }
    }

    static long readVarint(InputStream in) throws IOException {
        long result = 0;
        int shift = 0;
        while (true) {
            int b = in.read();
            if (b < 0) throw new EOFException("Connection closed");
            result |= (long) (b & 0x7F) << shift;
            if ((b & 0x80) == 0) return result;
            shift += 7;
            if (shift > 63) throw new IOException("Varint too long");
        }
    }

    /** Messages on the wire are prefixed with their length as a varint. */
    public static byte[] readDelimited(InputStream in) throws IOException {
        int len = (int) readVarint(in);
        if (len < 0 || len > 1_000_000) throw new IOException("Bad message length " + len);
        byte[] buf = new byte[len];
        int off = 0;
        while (off < len) {
            int n = in.read(buf, off, len - off);
            if (n < 0) throw new EOFException("Connection closed");
            off += n;
        }
        return buf;
    }

    public static void writeDelimited(OutputStream out, byte[] msg) throws IOException {
        Writer len = new Writer();
        len.raw(msg.length);
        byte[] prefix = len.toByteArray();
        byte[] all = new byte[prefix.length + msg.length];
        System.arraycopy(prefix, 0, all, 0, prefix.length);
        System.arraycopy(msg, 0, all, prefix.length, msg.length);
        out.write(all);
        out.flush();
    }
}
