plugins {
    id("com.android.application")
}

android {
    namespace = "com.hend.tvremote"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hend.tvremote"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
