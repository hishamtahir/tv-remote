plugins {
    id("com.android.application")
}

val buildNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "com.hend.tvremote"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hend.tvremote"
        minSdk = 24
        targetSdk = 34
        versionCode = buildNumber
        versionName = "2.0.$buildNumber"
    }

    // A fixed signing key, so every new version installs over the old one.
    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storePassword = "tvremote2026"
            keyAlias = "tvremote"
            keyPassword = "tvremote2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
